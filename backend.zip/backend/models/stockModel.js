const mongoose = require('mongoose');

const stockSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    availableQuantity: { type: Number, required: true },
    symbol: { type: String, required: true, unique: true }, // Ensure 'symbol' is defined as required and unique
});

module.exports = mongoose.model('Stock', stockSchema);



