const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    walletAddress: { type: String, required: true, unique: true },
    portfolio: [
        {
            stockId: { type: mongoose.Schema.Types.ObjectId, ref: 'Stock', required: true },
            quantity: { type: Number, required: true },
            stockName: { type: String, required: true },
            stockSymbol: { type: String, required: true },
            purchasedAt: { type: Date, default: Date.now },
        },
    ],
},
{
    timestamps: true,
});

module.exports = mongoose.model('User', UserSchema);





