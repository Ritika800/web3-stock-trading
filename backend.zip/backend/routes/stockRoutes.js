const express = require('express');
const stockController = require('../controllers/stockController');
const {
    getAllStocks,
    getStockById,
    buyStock,
    sellStock,
    addStock,
    deleteStock,
    addOrUpdateStock
} = stockController;

const router = express.Router();

// Middleware to validate request data for buying stock
const validateBuyRequest = (req, res, next) => {
    const { stockId, walletAddress, quantity, paymentMethod, paymentAmount } = req.body;

    // Validation to ensure required fields exist in the request body
    if (!stockId || !walletAddress || quantity === undefined || !paymentMethod || paymentAmount === undefined) {
        return res.status(400).json({ error: "Missing required fields (stockId, walletAddress, quantity, paymentMethod, paymentAmount)" });
    }

    // Ensure quantity is a positive number
    if (typeof quantity !== 'number' || quantity <= 0) {
        return res.status(400).json({ error: "Quantity must be a positive number" });
    }

    // Ensure paymentAmount is a valid number greater than zero
    if (typeof paymentAmount !== 'string' || isNaN(Number(paymentAmount)) || Number(paymentAmount) <= 0) {
        return res.status(400).json({ error: "Payment Amount must be a valid number greater than zero" });
    }

    // Ensure wallet address is a valid string
    if (typeof walletAddress !== 'string' || walletAddress.trim() === '') {
        return res.status(400).json({ error: "Wallet address must be a valid string" });
    }

    next();
};

// Buy a stock (with validation)
router.post('/buy', stockController.buyStock);

// Sell a stock
router.post('/sell', sellStock);

// Add new stock (for testing or seeding purposes)
router.post('/', addStock);

// Add or update stock
router.post('/addOrUpdate', addOrUpdateStock);

// Get all available stocks
router.get('/', getAllStocks);

// Get stock details by ID (❗MUST be last to avoid route conflicts)
router.get('/:id', getStockById);

// Delete stock by ID
router.delete('/:stockId', deleteStock);

module.exports = router;
