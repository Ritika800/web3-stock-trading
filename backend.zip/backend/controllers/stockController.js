const Stock = require('../models/stockModel');
const User = require('../models/userModel');
const { ethers } = require('ethers');

const contractAddress = "0xe08354211fB7d2F750D0E2dEDDc9d7228Ca8aC1c";
const contractABI = [
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "buyer",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "stockId",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        }
      ],
      "name": "StockBought",
      "type": "event"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "buyer",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "stockId",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        }
      ],
      "name": "buyStock",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function"
    }
  ];

exports.getAllStocks = async (req, res) => {
    try {
        const stocks = await Stock.find();
        if (!stocks || stocks.length === 0) {
            return res.status(404).json({ message: "No stocks found" });
        }
        res.status(200).json(stocks);
    } catch (error) {
        console.error("Error in getAllStocks:", error);
        res.status(500).json({ error: "Server Error: Unable to fetch stocks", details: error.message });
    }
};

exports.addStock = async (req, res) => {
    try {
        const { name, price, availableQuantity, symbol } = req.body;

        if (name === undefined || price === undefined || availableQuantity === undefined || symbol === undefined) {
            return res.status(400).json({ error: "Missing required fields (name, price, availableQuantity, symbol)" });
        }

        const newStock = new Stock({ name, price, availableQuantity, symbol });

        await newStock.save();
        res.status(201).json({ message: "Stock added successfully", stock: newStock });
    } catch (error) {
        console.error("Error in addStock:", error);
        res.status(500).json({ error: "Server Error: Unable to add stock", details: error.message });
    }
};

exports.updateStockPrice = async (req, res) => {
    try {
        const { stockId } = req.params;
        const { newPrice } = req.body;

        if (newPrice === undefined) {
            return res.status(400).json({ error: "Missing required field: newPrice" });
        }

        const stock = await Stock.findById(stockId);
        if (!stock) {
            return res.status(404).json({ error: "Stock not found" });
        }

        stock.price = newPrice;
        await stock.save();
        res.json({ message: "Stock price updated", stock });
    } catch (error) {
        console.error("Error in updateStockPrice:", error);
        res.status(500).json({ error: "Server Error: Unable to update stock price", details: error.message });
    }
};
exports.buyStock = async (req, res) => {
    try {
        console.log("Incoming req.body:", JSON.stringify(req.body, null, 2));

        const { wallet: walletAddress, stockId, quantity, paymentMethod, paymentAmount } = req.body;

        if (!walletAddress || !stockId || quantity === undefined || !paymentMethod || paymentAmount === undefined) {
            console.warn(" Missing fields:", { walletAddress, stockId, quantity, paymentMethod, paymentAmount });
            return res.status(400).json({
                error: "Missing required fields (walletAddress, stockId, quantity, paymentMethod, paymentAmount)",
                received: req.body
            });
        }

        if (Number(quantity) <= 0) {
            return res.status(400).json({ error: "Quantity must be greater than zero" });
        }

        if (Number(paymentAmount) <= 0 && paymentMethod === 'ETH') {
            console.warn("Payment amount is zero or less for ETH purchase. Smart contract requires msg.value > 0.");
            return res.status(400).json({ error: "Payment amount must be greater than zero for ETH purchase" });
        }

        const stock = await Stock.findById(stockId);
        if (!stock) {
            return res.status(404).json({ error: "Stock not found" });
        }

        if (stock.availableQuantity < quantity) {
            return res.status(400).json({ error: "Not enough stock available" });
        }

        let user = await User.findOne({ walletAddress });
        if (!user) {
            user = new User({ walletAddress, portfolio: [] });
        }

        
        const existingItemIndex = user.portfolio.findIndex(item => item.stockId?.equals(stock._id));
        if (existingItemIndex !== -1) {
            user.portfolio[existingItemIndex].quantity += quantity;
            user.portfolio[existingItemIndex].stockName = stock.name;
            user.portfolio[existingItemIndex].stockSymbol = stock.symbol; 
        } else {
            user.portfolio.push({
                stockId: stock._id,
                quantity,
                stockName: stock.name,
                stockSymbol: stock.symbol, 
            });
        }
    
        console.log(" Portfolio before save:", JSON.stringify(user.portfolio, null, 2));

        await user.save();  

        const updatedQuantity = stock.availableQuantity - quantity;
        const updateResult = await Stock.findOneAndUpdate(
            { _id: stockId },
            { availableQuantity: updatedQuantity },
            { new: true }
        );
        console.log(" Stock updated:", updateResult);

        let transactionHash = 'simulated_transaction_hash';

        if (paymentMethod === 'ETH') {
            try {
                const provider = new ethers.JsonRpcProvider("https://sepolia.infura.io/v3/287e5121962146b4b4830d8d509fdcd4");  // replace with your infra id
                const walletPrivateKey = "2fb978f96351c74df2069e4e6f0766b24dabad9ad326fd028fbe683f9013d258";   //replace with your private key
                const walletInstance = new ethers.Wallet(walletPrivateKey, provider);
                const contract = new ethers.Contract(contractAddress, contractABI, walletInstance);
                const paymentAmountInWei = ethers.utils.parseEther(paymentAmount.toString());

                const transaction = await contract.buyStock(walletAddress, stock._id.toString(), quantity, {
                    value: paymentAmountInWei,
                    gasLimit: 1000000,
                });

                const receipt = await transaction.wait();
                transactionHash = receipt.transactionHash;
                console.log("Smart contract transaction hash:", transactionHash);
            } catch (error) {
                console.error("Smart Contract Error:", error);
                return res.status(500).json({ error: "Smart Contract interaction failed", details: error.message });
            }
        } else {
            console.log(` Simulated purchase for ${walletAddress} of ${quantity} units`);
        }

        res.status(200).json({
            message: "Stock purchased successfully",
            portfolio: user.portfolio,
            transactionHash,
        });

    } catch (error) {
        console.error("Server Error in buyStock:", error);
        res.status(500).json({ error: "Server Error: Unable to buy stock", details: error.message });
    }
};
exports.getStockById = async (req, res) => {
    try {
        const stock = await Stock.findById(req.params.id);
        if (!stock) {
            return res.status(404).json({ error: "Stock not found" });
        }
        res.json(stock);
    } catch (err) {
        console.error("Error in getStockById:", err);
        res.status(500).json({ error: "Server Error: Unable to fetch stock by ID", details: err.message });
    }
};

exports.sellStock = async (req, res) => {
    try {
        const { walletAddress, stockId, quantity } = req.body;

        if (walletAddress === undefined || stockId === undefined || quantity === undefined) {
            return res.status(400).json({ error: "Missing required fields (walletAddress, stockId, quantity)" });
        }

        const user = await User.findOne({ walletAddress });
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        const portfolioItem = user.portfolio.find(item => item.stockId?.equals(stockId));
        if (!portfolioItem || portfolioItem.quantity < quantity) {
            return res.status(400).json({ error: "Not enough stock to sell" });
        }

        const stock = await Stock.findById(stockId);
        if (!stock) {
            return res.status(404).json({ error: "Stock not found" });
        }

        portfolioItem.quantity -= quantity;
        if (portfolioItem.quantity === 0) {
            user.portfolio = user.portfolio.filter(item => !item.stockId?.equals(stockId));
        }

        stock.availableQuantity += quantity;

        await user.save();
        await stock.save();

        res.json({ message: "Stock sold successfully", portfolio: user.portfolio });

    } catch (err) {
        console.error("Error in sellStock:", err);
        res.status(500).json({ error: "Server Error: Unable to sell stock", details: err.message });
    }
};

exports.deleteStock = async (req, res) => {
    try {
        const { stockId } = req.params;
        const deleted = await Stock.findByIdAndDelete(stockId);

        if (!deleted) {
            return res.status(404).json({ error: "Stock not found" });
        }

        res.json({ message: "Stock deleted successfully" });
    } catch (err) {
        console.error("Error in deleteStock:", err);
        res.status(500).json({ error: "Server Error: Unable to delete stock", details: err.message });
    }
};

exports.addOrUpdateStock = async (req, res) => {
    try {
        const { name, price, availableQuantity, symbol } = req.body;

        if (name === undefined || price === undefined || availableQuantity === undefined || symbol === undefined) {
            return res.status(400).json({ error: "Missing required fields (name, price, availableQuantity, symbol)" });
        }

        const existingStock = await Stock.findOne({ name });

        if (existingStock) {
            existingStock.price = price;
            existingStock.availableQuantity = availableQuantity;
            existingStock.symbol = symbol;
            await existingStock.save();

            return res.status(200).json({ message: "Stock updated", stock: existingStock });
        }

        const newStock = new Stock({ name, price, availableQuantity, symbol });
        await newStock.save();

        res.status(201).json({ message: "Stock added", stock: newStock });
    } catch (err) {
        console.error("Error in addOrUpdateStock:", err);
        res.status(500).json({ error: "Server Error: Unable to add or update stock", details: err.message });
    }
};
