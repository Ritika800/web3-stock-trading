const User = require('../models/userModel');
const Stock = require('../models/stockModel'); // ✅ Import Stock to get symbol/name

// Register a new user
exports.registerUser = async (req, res) => {
    const { walletAddress } = req.body;
    try {
        const normalizedWallet = walletAddress.toLowerCase();
        const existingUser = await User.findOne({ walletAddress: normalizedWallet });
        if (existingUser) return res.status(400).json({ error: "User already exists" });

        const newUser = new User({ walletAddress: normalizedWallet, portfolio: [] });
        await newUser.save();

        res.status(201).json({ message: "User registered", user: newUser });
    } catch (err) {
        res.status(500).json({ error: "Server Error: Unable to register user" });
    }
};

// ✅ Updated getUserProfile
exports.getUserProfile = async (req, res) => {
    const { walletAddress } = req.params;
    try {
        const user = await User.findOne({ walletAddress: walletAddress.toLowerCase() })
            .populate({
                path: 'portfolio.stockId',
                model: 'Stock',
                select: 'symbol name price'
            });

        if (!user) return res.status(404).json({ error: "User not found" });

        const formattedPortfolio = user.portfolio.map(entry => {
            const stock = entry.stockId;

            return {
                _id: entry._id,
                stockId: stock?._id || entry.stockId,
                stockSymbol: stock?.symbol || 'SYM',
                stockName: stock?.name || 'Unknown',
                stockPrice: stock?.price || 0,
                quantity: entry.quantity,
                purchasedAt: entry.purchasedAt
            };
        });

        res.json({
            walletAddress: user.walletAddress,
            portfolio: formattedPortfolio
        });
    } catch (err) {
        console.error("Error fetching user profile:", err);
        res.status(500).json({ error: "Server Error: Unable to fetch user profile" });
    }
};

exports.loginUser = async (req, res) => {
    try {
        const { walletAddress } = req.body;
        const normalizedWallet = walletAddress.toLowerCase();

        let user = await User.findOne({ walletAddress: normalizedWallet });
        if (!user) {
            user = new User({ walletAddress: normalizedWallet, portfolio: [] });
            await user.save();
        }

        res.json({ message: "User logged in successfully", user });
    } catch (err) {
        res.status(500).json({ error: "Server Error: Unable to log in user" });
    }
};

exports.getUserPortfolio = async (req, res) => {
    try {
        const { walletAddress } = req.params;
        const normalizedWallet = walletAddress.toLowerCase();

        const user = await User.findOne({ walletAddress: normalizedWallet }).populate('portfolio.stockId');
        if (!user) return res.status(404).json({ error: "User not found" });

        const formattedPortfolio = user.portfolio.map(entry => ({
            _id: entry._id,
            stockId: entry.stockId?._id || entry.stockId,
            stockSymbol: entry.stockId?.symbol || 'SYM',
            stockName: entry.stockId?.name || 'Unknown',
            quantity: entry.quantity,
            purchasedAt: entry.purchasedAt
        }));

        res.json({ portfolio: formattedPortfolio });
    } catch (err) {
        res.status(500).json({ error: "Server Error: Unable to fetch portfolio" });
    }
};

// ✅ Improved updatePortfolio: ensures stock exists before updating
exports.updatePortfolio = async (req, res) => {
    try {
        const { walletAddress, stockId, quantity } = req.body;

        if (!walletAddress || !stockId || typeof quantity !== 'number') {
            return res.status(400).json({ error: "Missing required fields: walletAddress, stockId, quantity" });
        }

        const normalizedWallet = walletAddress.toLowerCase();
        const user = await User.findOne({ walletAddress: normalizedWallet });
        if (!user) return res.status(404).json({ error: "User not found" });

        // 🔍 Check if stock exists
        const stock = await Stock.findById(stockId);
        if (!stock) return res.status(404).json({ error: "Stock not found" });

        const stockIndex = user.portfolio.findIndex(item => item.stockId?.toString() === stockId);

        if (stockIndex !== -1) {
            user.portfolio[stockIndex].quantity += quantity;
        } else {
            // ✅ Include stockName and stockSymbol when adding a new item
            user.portfolio.push({ stockId, quantity, stockName: stock.name, stockSymbol: stock.symbol });
        }

        await user.save();
        res.json({ message: "Portfolio updated successfully", portfolio: user.portfolio });
    } catch (err) {
        console.error("Error updating portfolio:", err);
        res.status(500).json({ error: "Server Error: Unable to update portfolio" });
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const { walletAddress } = req.params;

        const user = await User.findOneAndDelete({ walletAddress: walletAddress.toLowerCase() });
        if (!user) return res.status(404).json({ error: "User not found" });

        res.json({ message: "User deleted successfully" });
    } catch (err) {
        res.status(500).json({ error: "Server Error: Unable to delete user" });
    }
};
