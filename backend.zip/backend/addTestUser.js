require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/userModel');

mongoose.connect(process.env.MONGO_URI);

const run = async () => {
  const wallet = "0x1111111111111111111111111111111111111111";
  
  const existingUser = await User.findOne({ walletAddress: wallet });

  if (existingUser) {
    console.log(" User already exists with this wallet address");
  } else {
    await User.create({
      walletAddress: wallet,
      portfolio: [],
    });
    console.log("Test user added successfully");
  }

  mongoose.disconnect();
};

run();

