const mongoose = require('mongoose'); 
mongoose.set('debug', true); 

const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
require('dotenv').config();

const app = express();

const initializeApp = async () => {
  try {
    await connectDB();  
    console.log('Database connected');
  } catch (error) {
    console.error('Error connecting to database:', error);
    process.exit(1);  
  }
};

initializeApp();

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',  
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Root test route
app.get('/', (req, res) => {
  res.send('Backend is live');
});

// Route definitions
app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/stocks', require('./routes/stockRoutes'));

app.use((req, res, next) => {
  const error = new Error('Not Found');
  error.status = 404;
  next(error);
});

// Global error handler
app.use((err, req, res, next) => {
  const statusCode = err.status || 500;
  const message = err.message || 'Internal Server Error';
  res.status(statusCode).json({ error: message });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
